import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListEmployeeComponent } from './list-employee/list-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { GalleryComponent } from './gallery/gallery.component';
import { LoginComponent } from './login/login.component';


const routes: Routes = [{ path: 'listemp', component: ListEmployeeComponent },
{ path: 'addemp', component: AddEmployeeComponent },
{ path: '', component: HomepageComponent },
{ path: 'updateemp', component: UpdateEmployeeComponent },
{ path: 'homepage', component: HomepageComponent },
{ path: 'contact', component: ContactUSComponent },
{ path: 'aboutus', component: GalleryComponent },
{ path: 'login', component: LoginComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
